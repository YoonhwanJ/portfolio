var clickText = document.querySelector('.click-text');

function teleport1(){
    window.scrollTo(0, 0)
}

function teleport2(){
    window.scrollTo(0, 880)
}

function teleport3(){
    window.scrollTo(0, 1760)
}

function teleport4(){
    window.scrollTo(0, 2640)
}

function teleport5(){
    window.scrollTo(0, 3520)
}

function teleport6(){
    window.scrollTo(0, 4400)
}

